from flask_wtf import FlaskForm
from flask import Flask, render_template, request, redirect, session
from wtforms import StringField, PasswordField, BooleanField, SubmitField, TextAreaField
from wtforms.validators import DataRequired
import json
from db1 import UsersModel, NewsModel, DB, CommentsModel
from flask_socketio import SocketIO
db = DB()

user_model = UsersModel(db.get_connection())
users = user_model.init_table()

news_model = NewsModel(db.get_connection())
news = news_model.init_table()

comment_model = CommentsModel(db.get_connection())
comments = comment_model.init_table()

app = Flask(__name__)
app.config['SECRET_KEY'] = 'kitten_secret_key'
socketio = SocketIO(app)

class LoginForm(FlaskForm):
    username = StringField('Логин', validators=[DataRequired()])
    password = PasswordField('Пароль', validators=[DataRequired()])
    remember_me = BooleanField('Запомнить меня')
    submit = SubmitField('Войти')
    
class RegistrationForm(FlaskForm):
    username = StringField('Логин', validators=[DataRequired()])
    password = PasswordField('Пароль', validators=[DataRequired()])
    remember_me = BooleanField('Запомнить меня')
    submit = SubmitField('Зарегистрироваться')
    
class AddNewsForm(FlaskForm):
    title = StringField('Заголовок Новости', validators=[DataRequired()])
    content = TextAreaField('Текст новости', validators=[DataRequired()])
    submit = SubmitField('Добавить')
    
class AddCommentsForm(FlaskForm): 
    content = TextAreaField('Текст комментария', validators=[DataRequired()])
    submit = SubmitField('Добавить')

@app.route('/')
def home():
    return render_template("home3.html")

@app.route('/users')
def users():
    if session['username'] == 'administrator' and session['user_id'] == 3:
        users = UsersModel(db.get_connection()).get_all()
        return render_template('users5.html', 
                                   users=users)        
    else:
        users = UsersModel(db.get_connection()).get_all()
        liist = users
        newliist = []
        for element in liist:
            number = element[0]
            username = element[1]
            tup = (number, username)
            newliist.append(tup)
        return render_template('users5.html', 
                               users=newliist)        

@app.route('/show_news/<int:user_id>')
def show_news(user_id):
    news = NewsModel(db.get_connection()).get_all(user_id)
    users = UsersModel(db.get_connection()).get_all()
    comments = CommentsModel(db.get_connection()).get_all_from_all_users() #######
    current_user = session['user_id']
    for user in users:
        if user[0] == user_id:
            username = user[1]
    if session['username'] == 'administrator' and session['user_id'] == 3:
        return render_template('indexadm6.html', 
                               news=news, current_user=current_user, comments=comments, users=users,  username=username)  
    else:
        return render_template('index_regular_watch6.html', 
                               news=news, current_user=current_user, comments=comments, users=users,  username=username)      

@app.route('/add_comments_while_watching/<int:news_id>', methods=['GET', 'POST'])
def add_comments_while_watching(news_id):
    if 'username' not in session:
        return redirect('/login')
    form = AddCommentsForm()
    news = NewsModel(db.get_connection()).get_all_from_all_users()
    users = UsersModel(db.get_connection()).get_all()
    comments = CommentsModel(db.get_connection()).get_all_from_all_users() 
    if form.validate_on_submit():
        content = form.content.data
        cm = CommentsModel(db.get_connection())
        cm.insert(news_id,content,session['user_id'])
        for item in news:
            if item[0] == news_id:
                user_id = item[3]
        user_id = int(user_id)
        line = '/show_news/' + str(user_id)
        return redirect(line)
    return render_template('add_comments1.html', title='Добавление комментария',
                           form=form, username=session['username'])

@app.route('/delete_comments_while_watching/<int:comments_id>', methods=['GET']) 
def delete_comments_while_watching(comments_id):  
    if 'username' not in session:
        return redirect('/login')
    news = NewsModel(db.get_connection()).get_all_from_all_users()
    users = UsersModel(db.get_connection()).get_all()
    comments = CommentsModel(db.get_connection()).get_all_from_all_users() 
    for item in comments:
        print(item, comments_id)
        if item[0] == comments_id:
            news_id = item[1]
    for item in news:
        if item[0] == news_id:
            user_id = item[3]
    user_id = int(user_id)
    print(user_id)
    line = '/show_news/' + str(user_id)
    cm = CommentsModel(db.get_connection())
    cm.delete(comments_id)
    return redirect(line)

@app.route('/add_news_adm', methods=['GET', 'POST'])
def add_news_adm():
    if session['username'] == 'administrator' and session['user_id'] == 3:
        form = AddNewsForm()
        if form.validate_on_submit():
            title = form.title.data
            content = form.content.data
            nm = NewsModel(db.get_connection())
            nm.insert(title,content,'user_id')
            return redirect("/users")
        return render_template('add_news.html', title='Добавление новости',
                           form=form, username=session['username'])
 
@app.route('/delete_news_adm/<int:news_id>', methods=['GET'])
def delete_news_adm(news_id):
    if session['username'] == 'administrator' and session['user_id'] == 3:
        news = NewsModel(db.get_connection()).get_all_from_all_users()
        for item in news:
            if item[0] == news_id:
                user_id = item[3]
        user_id = int(user_id)
        print(user_id)
        line = '/show_news/' + str(user_id)
        nm = NewsModel(db.get_connection())
        nm.delete(news_id)
        return redirect(line)

@app.route('/registration', methods=['GET', 'POST'])
def registration():
    form = RegistrationForm()
    if form.validate_on_submit():
        user_name = form.username.data
        password = form.password.data
        user_model = UsersModel(db.get_connection())
        exists = user_model.exists(user_name, password)
        if not (exists[0]):
            user_model.insert(user_name, password)
        return redirect('/')    
    return render_template('registration.html', title='Регистрация', form=form)

@app.route('/login', methods=['GET', 'POST'])
def login():
    form = LoginForm()
    if form.validate_on_submit():
        user_name = form.username.data
        password = form.password.data
        user_model = UsersModel(db.get_connection())
        exists = user_model.exists(user_name, password)
        if (exists[0]):
            session['username'] = user_name
            session['user_id'] = exists[1]
            return redirect('/index')    
    return render_template('login.html', title='Авторизация', form=form)

@app.route('/logout')
def logout():
    session.pop('username',0)
    session.pop('user_id',0)
    return redirect('/login')

@app.route('/index')
def index():
    if 'username' not in session:
        return redirect('/login')
    news = NewsModel(db.get_connection()).get_all(session['user_id'])
    
    comments = CommentsModel(db.get_connection()).get_all_from_all_users() 
    users = UsersModel(db.get_connection()).get_all() 
    liist = comments
    showable = []
    for element in liist:
        com_id = element[0]
        news_id = element[1]
        cont = element[2]
        usr_id = element[3]
        tup = (com_id, cont, usr_id)
        showable.append(tup)    
    for comment in comments:
        print(comment)
    for piece_of_news in news:
        print(piece_of_news)
    for userline in users:
        print(userline)
    return render_template('index15.html', username=session['username'],
                           news=news, comments=comments, users=users)    

@app.route('/add_news', methods=['GET', 'POST'])
def add_news():
    if 'username' not in session:
        return redirect('/login')
    form = AddNewsForm()
    if form.validate_on_submit():
        title = form.title.data
        content = form.content.data
        nm = NewsModel(db.get_connection())
        nm.insert(title,content,session['user_id'])
        return redirect("/index")
    return render_template('add_news.html', title='Добавление новости',
                           form=form, username=session['username'])

@app.route('/add_comments/<int:news_id>', methods=['GET', 'POST'])
def add_comments(news_id):
    if 'username' not in session:
        return redirect('/login')
    form = AddCommentsForm()
    print(comments)
    if form.validate_on_submit():
        #title = form.title.data
        content = form.content.data
        cm = CommentsModel(db.get_connection())
        cm.insert(news_id,content,session['user_id'])
        
        return redirect("/index")
    return render_template('add_comments1.html', title='Добавление комментария',
                           form=form, username=session['username'])
 
@app.route('/delete_news/<int:news_id>', methods=['GET'])
def delete_news(news_id):
    if 'username' not in session:
        return redirect('/login')
    nm = NewsModel(db.get_connection())
    nm.delete(news_id)
    return redirect("/index")


@app.route('/delete_comments/<int:comments_id>', methods=['GET']) 
def delete_comments(comments_id):
    if 'username' not in session:
        return redirect('/login')
    cm = CommentsModel(db.get_connection())
    cm.delete(comments_id)
    return redirect("/index")

@app.route('/chat')
def sessions():
    return render_template('session1.html')
def messageReceived(methods=['GET', 'POST']):
    print('message was received!!!')
@socketio.on('my event')
def handle_my_custom_event(json, methods=['GET', 'POST']):
    print('received my event: ' + str(json))
    socketio.emit('my response', json, callback=messageReceived)


if __name__ == '__main__':
    app.run(port=8080, host='127.0.0.1')